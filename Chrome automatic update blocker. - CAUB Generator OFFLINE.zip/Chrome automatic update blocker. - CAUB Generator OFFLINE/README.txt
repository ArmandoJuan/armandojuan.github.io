Run the file "index.html"

-DON'T CHANGE THE FILE LOCATION. IT MUST BE TOGETHER WITH THE OTHER .JS's FILES

The file "old.html" is a older version of the website, it may be usefull.

The "Original backups" folder, is a folder with the original html files not modified. The other files (those who are in the root file) are modified to run the .js files offline.
