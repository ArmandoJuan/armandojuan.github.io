// Copyright (c) DerDer56
if (!location.protocol[5]) {
  location.protocol = "https:"
}